
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { LevelData, ObjectType, GameObject, UserSettings } from '../types';
import { BLOCK_SIZE, GAME_WIDTH, GAME_HEIGHT } from '../constants';
import GameCanvas from './GameCanvas';

interface AIHistoryItem {
  id: string;
  name: string;
  prompt: string;
  objects: GameObject[];
  timestamp: number;
}

interface EditorProps {
  onSave: (level: LevelData) => void;
  onExit: () => void;
  settings: UserSettings;
  initialLevel?: LevelData;
}

type Tool = ObjectType | 'ERASER';

const SESSION_STORAGE_DRAFT_KEY = 'usual_puppet_editor_session_draft';
const CHUNK_SIZE = 400; // Spatial partitioning size

// Helper to get portal hue based on type for sprite generation
const getPortalHue = (type: ObjectType): number => {
  if (type === ObjectType.PORTAL_SHIP) return 0;
  if (type === ObjectType.PORTAL_BALL) return 30;
  if (type === ObjectType.PORTAL_UFO) return 120;
  if (type === ObjectType.PORTAL_WAVE) return 190;
  if (type === ObjectType.PORTAL_ROBOT) return 60;
  if (type === ObjectType.PORTAL_SPIDER) return 330;
  if (type === ObjectType.PORTAL_SWING) return 240;
  if (type === ObjectType.PORTAL_JETPACK) return 270;
  return 300;
};

const Editor: React.FC<EditorProps> = ({ onSave, onExit, settings, initialLevel }) => {
  const [level, setLevel] = useState<LevelData>(() => {
    const saved = sessionStorage.getItem(SESSION_STORAGE_DRAFT_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (initialLevel) {
          if (parsed.level && parsed.level.id === initialLevel.id) return parsed.level;
        } else {
          if (parsed.level && parsed.level.id.toString().startsWith('custom')) return parsed.level;
        }
      } catch (e) {
        console.error("Error parsing editor session draft", e);
      }
    }
    return initialLevel || {
      id: `custom-${Date.now()}`,
      name: 'New Puppet Level',
      difficulty: 'Easy',
      objects: []
    };
  });

  const [activeTool, setActiveTool] = useState<Tool>(() => {
    const saved = sessionStorage.getItem(SESSION_STORAGE_DRAFT_KEY);
    if (saved) {
      try {
        return JSON.parse(saved).activeTool || ObjectType.BLOCK;
      } catch { return ObjectType.BLOCK; }
    }
    return ObjectType.BLOCK;
  });

  const [scrollX, setScrollX] = useState<number>(() => {
    const saved = sessionStorage.getItem(SESSION_STORAGE_DRAFT_KEY);
    if (saved) {
      try {
        return JSON.parse(saved).scrollX || 0;
      } catch { return 0; }
    }
    return 0;
  });

  const [snapToGrid, setSnapToGrid] = useState<boolean>(() => {
    const saved = sessionStorage.getItem(SESSION_STORAGE_DRAFT_KEY);
    if (saved) {
      try {
        const val = JSON.parse(saved).snapToGrid;
        return val !== undefined ? val : true;
      } catch { return true; }
    }
    return true;
  });

  const [confirmingAction, setConfirmingAction] = useState<'SAVE' | 'EXIT' | 'CLEAR' | 'ARCHIVE' | null>(null);
  const [undoStack, setUndoStack] = useState<GameObject[][]>([]);
  const [redoStack, setRedoStack] = useState<GameObject[][]>([]);
  
  // Preview Mode State
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [previewSessionId, setPreviewSessionId] = useState(0);
  const [previewStatus, setPreviewStatus] = useState<'PLAYING' | 'GAMEOVER' | 'WIN'>('PLAYING');
  const [previewCoins, setPreviewCoins] = useState(0);

  const [aiHistory, setAiHistory] = useState<AIHistoryItem[]>([]);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const spriteCacheRef = useRef<Map<ObjectType, HTMLCanvasElement>>(new Map());
  const gridCacheRef = useRef<HTMLCanvasElement | null>(null);

  // Load AI History
  useEffect(() => {
    const historyJson = localStorage.getItem('puppet_dash_ai_history');
    if (historyJson) {
      try {
        setAiHistory(JSON.parse(historyJson));
      } catch (e) { console.error(e); }
    }
  }, [confirmingAction]); 

  // Spatial Index (Bins)
  const spatialIndex = useMemo(() => {
    const index = new Map<number, GameObject[]>();
    level.objects.forEach(obj => {
      const chunkX = Math.floor(obj.x / CHUNK_SIZE);
      const chunkXEnd = Math.floor((obj.x + BLOCK_SIZE) / CHUNK_SIZE);
      for (let i = chunkX; i <= chunkXEnd; i++) {
        if (!index.has(i)) index.set(i, []);
        index.get(i)!.push(obj);
      }
    });
    return index;
  }, [level.objects]);

  // Sprite Cache Initialization
  useEffect(() => {
    spriteCacheRef.current.clear();
    Object.values(ObjectType).forEach(type => {
      const offscreen = document.createElement('canvas');
      offscreen.width = BLOCK_SIZE;
      offscreen.height = BLOCK_SIZE;
      if (type.startsWith('PORTAL_')) {
        offscreen.height = 80;
      }
      const ctx = offscreen.getContext('2d');
      if (!ctx) return;

      if (type === ObjectType.BLOCK) {
        ctx.fillStyle = settings.primaryColor;
        ctx.fillRect(0, 0, BLOCK_SIZE, BLOCK_SIZE);
        ctx.strokeStyle = 'rgba(255,255,255,0.3)';
        ctx.strokeRect(2, 2, BLOCK_SIZE - 4, BLOCK_SIZE - 4);
      } else if (type === ObjectType.SPIKE) {
        ctx.fillStyle = '#ff3333';
        ctx.beginPath();
        ctx.moveTo(4, BLOCK_SIZE);
        ctx.lineTo(BLOCK_SIZE / 2, 4);
        ctx.lineTo(BLOCK_SIZE - 4, BLOCK_SIZE);
        ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.3)';
        ctx.stroke();
      } else if (type.startsWith('PORTAL_')) {
        const hue = getPortalHue(type);
        ctx.strokeStyle = `hsl(${hue}, 100%, 50%)`;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.ellipse(BLOCK_SIZE/2, 40, 12, 35, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = `hsla(${hue}, 100%, 50%, 0.1)`;
        ctx.fill();
      } else if (type === ObjectType.COIN) {
        ctx.fillStyle = '#ffd700';
        ctx.beginPath(); ctx.arc(BLOCK_SIZE / 2, BLOCK_SIZE / 2, 8, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#fff';
        ctx.stroke();
      }
      spriteCacheRef.current.set(type, offscreen);
    });
  }, [settings.primaryColor]);

  // Grid Background Cache
  useEffect(() => {
    const offscreen = document.createElement('canvas');
    offscreen.width = CHUNK_SIZE;
    offscreen.height = GAME_HEIGHT;
    const ctx = offscreen.getContext('2d');
    if (!ctx) return;

    ctx.strokeStyle = snapToGrid ? '#222' : '#141414';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 0; x <= CHUNK_SIZE; x += BLOCK_SIZE) {
      ctx.moveTo(x, 0); ctx.lineTo(x, GAME_HEIGHT);
    }
    for (let y = 0; y < GAME_HEIGHT; y += BLOCK_SIZE) {
      ctx.moveTo(0, y); ctx.lineTo(CHUNK_SIZE, y);
    }
    ctx.stroke();
    gridCacheRef.current = offscreen;
  }, [snapToGrid]);

  useEffect(() => {
    const stateToSave = { level, activeTool, scrollX, snapToGrid };
    sessionStorage.setItem(SESSION_STORAGE_DRAFT_KEY, JSON.stringify(stateToSave));
  }, [level, activeTool, scrollX, snapToGrid]);

  const pushToUndo = (objects: GameObject[]) => {
    setUndoStack(prev => {
      const next = [...prev, [...objects]];
      if (next.length > 50) return next.slice(1);
      return next;
    });
    setRedoStack([]);
  };

  const undo = useCallback(() => {
    if (undoStack.length === 0) return;
    const previous = undoStack[undoStack.length - 1];
    setRedoStack(prev => [...prev, [...level.objects]]);
    setUndoStack(prev => prev.slice(0, -1));
    setLevel(prev => ({ ...prev, objects: previous }));
  }, [undoStack, level.objects]);

  const redo = useCallback(() => {
    if (redoStack.length === 0) return;
    const next = redoStack[redoStack.length - 1];
    setUndoStack(prev => [...prev, [...level.objects]]);
    setRedoStack(prev => prev.slice(0, -1));
    setLevel(prev => ({ ...prev, objects: next }));
  }, [redoStack, level.objects]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (confirmingAction || isPreviewing) {
        if (e.key === 'Escape' && !isPreviewing) setConfirmingAction(null);
        return;
      }
      if (e.ctrlKey || e.metaKey) {
        if (e.key === 'z' || e.key === 'Z') {
          if (e.shiftKey) redo(); else undo();
          e.preventDefault();
        } else if (e.key === 'y' || e.key === 'Y') {
          redo(); e.preventDefault();
        } else if (e.key === 's' || e.key === 'S') {
          setConfirmingAction('SAVE'); e.preventDefault();
        } else if (e.key === 'g' || e.key === 'G') {
          setSnapToGrid(prev => !prev); e.preventDefault();
        } else if (e.key === 'h' || e.key === 'H') {
          setConfirmingAction('ARCHIVE'); e.preventDefault();
        } else if (e.key === 'p' || e.key === 'P') {
          startPreview(); e.preventDefault();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [undo, redo, confirmingAction, isPreviewing]);

  const handleConfirmAction = () => {
    if (confirmingAction === 'SAVE') {
      sessionStorage.removeItem(SESSION_STORAGE_DRAFT_KEY);
      onSave(level);
    } else if (confirmingAction === 'EXIT') {
      sessionStorage.removeItem(SESSION_STORAGE_DRAFT_KEY);
      onExit();
    } else if (confirmingAction === 'CLEAR') {
      pushToUndo(level.objects);
      setLevel({ ...level, objects: [] });
    }
    setConfirmingAction(null);
  };

  const applyArchiveLayout = (objects: GameObject[]) => {
    pushToUndo(level.objects);
    setLevel(prev => ({ ...prev, objects: [...objects] }));
    setConfirmingAction(null);
    setScrollX(0); 
  };

  const startPreview = () => {
    setPreviewSessionId(Date.now());
    setPreviewStatus('PLAYING');
    setPreviewCoins(0);
    setIsPreviewing(true);
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (confirmingAction || isPreviewing) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const canvasX = (e.clientX - rect.left) * scaleX;
    const canvasY = (e.clientY - rect.top) * scaleY;

    const worldX = canvasX + scrollX;
    const worldY = canvasY;

    let x: number, y: number;
    if (snapToGrid) {
      x = Math.round(worldX / BLOCK_SIZE) * BLOCK_SIZE - (BLOCK_SIZE / 2);
      y = Math.round(worldY / BLOCK_SIZE) * BLOCK_SIZE - (BLOCK_SIZE / 2);
    } else {
      x = worldX - (BLOCK_SIZE / 2);
      y = worldY - (BLOCK_SIZE / 2);
    }
    
    const checkCenterX = worldX;
    const checkCenterY = worldY;
    const existingIndexInGlobal = level.objects.findIndex(o => 
      checkCenterX >= o.x && checkCenterX <= o.x + BLOCK_SIZE && 
      checkCenterY >= o.y && checkCenterY <= o.y + BLOCK_SIZE
    );

    if (activeTool === 'ERASER') {
      if (existingIndexInGlobal > -1) {
        pushToUndo(level.objects);
        const newObjects = [...level.objects];
        newObjects.splice(existingIndexInGlobal, 1);
        setLevel({ ...level, objects: newObjects });
      }
    } else {
      const newObj: GameObject = { id: `obj-${Date.now()}`, type: activeTool as ObjectType, x, y };
      if (existingIndexInGlobal > -1) {
        if (level.objects[existingIndexInGlobal].type !== activeTool) {
          pushToUndo(level.objects);
          const newObjects = [...level.objects];
          newObjects[existingIndexInGlobal] = newObj;
          setLevel({ ...level, objects: newObjects });
        }
      } else {
        pushToUndo(level.objects);
        setLevel({ ...level, objects: [...level.objects, newObj] });
      }
    }
  };

  // Optimized Rendering Loop
  useEffect(() => {
    if (isPreviewing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId = requestAnimationFrame(() => {
      ctx.clearRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
      
      // Draw Grid from cache
      if (gridCacheRef.current) {
        const xOffset = -scrollX % CHUNK_SIZE;
        for (let x = xOffset - CHUNK_SIZE; x < GAME_WIDTH + CHUNK_SIZE; x += CHUNK_SIZE) {
          ctx.drawImage(gridCacheRef.current, x, 0);
        }
      }
      
      // Floor line
      ctx.strokeStyle = settings.primaryColor;
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, 400); ctx.lineTo(GAME_WIDTH, 400); ctx.stroke();

      ctx.save();
      ctx.translate(-scrollX, 0);
      
      const startChunk = Math.floor(scrollX / CHUNK_SIZE);
      const endChunk = Math.floor((scrollX + GAME_WIDTH) / CHUNK_SIZE);

      const visibleObjects = new Set<GameObject>();
      for (let i = startChunk; i <= endChunk; i++) {
        const chunkObjects = spatialIndex.get(i);
        if (chunkObjects) {
          chunkObjects.forEach(obj => visibleObjects.add(obj));
        }
      }

      visibleObjects.forEach(obj => {
        const sprite = spriteCacheRef.current.get(obj.type);
        if (sprite) {
          const drawY = obj.type.startsWith('PORTAL_') ? obj.y + (BLOCK_SIZE / 2) - 40 : obj.y;
          ctx.drawImage(sprite, obj.x, drawY);
        }
      });
      ctx.restore();
    });

    return () => cancelAnimationFrame(animationFrameId);
  }, [level, scrollX, settings.primaryColor, snapToGrid, spatialIndex, isPreviewing]);

  if (isPreviewing) {
    return (
      <div className="h-screen w-screen bg-black flex items-center justify-center relative animate-in fade-in duration-700">
        <GameCanvas 
          key={previewSessionId}
          level={level}
          settings={settings}
          onGameOver={(coins) => { setPreviewCoins(coins); setPreviewStatus('GAMEOVER'); }}
          onWin={(coins) => { setPreviewCoins(coins); setPreviewStatus('WIN'); }}
          onQuit={() => setIsPreviewing(false)}
          onRestart={() => { setPreviewSessionId(Date.now()); setPreviewStatus('PLAYING'); }}
          isPausedExternal={previewStatus !== 'PLAYING'}
        />

        {previewStatus !== 'PLAYING' && (
          <div className="absolute inset-0 z-[200] bg-black/80 backdrop-blur-xl flex flex-col items-center justify-center animate-in fade-in zoom-in duration-500">
             <div className="text-center p-12 glass rounded-[64px] max-w-sm w-full shadow-2xl">
                <h3 className={`text-5xl font-orbitron font-black mb-2 ${previewStatus === 'WIN' ? 'text-emerald-400' : 'text-red-500'}`}>
                  {previewStatus === 'WIN' ? 'OPTIMIZED' : 'SEVERED'}
                </h3>
                <p className="text-white/20 text-[10px] font-bold uppercase tracking-[0.4em] mb-8">Playtest Feedback Collected</p>
                
                <div className="flex flex-col gap-4">
                   <button 
                    onClick={() => { setPreviewSessionId(Date.now()); setPreviewStatus('PLAYING'); }}
                    className="py-5 bg-white text-black font-black text-xl rounded-full hover:scale-105 transition-all shadow-xl active:scale-95"
                   >
                     REBOOT SESSION
                   </button>
                   <button 
                    onClick={() => setIsPreviewing(false)}
                    className="py-4 glass text-white/50 hover:text-white font-bold text-sm rounded-full transition-all active:scale-95 uppercase tracking-widest"
                   >
                     BACK TO WORKSHOP
                   </button>
                </div>
             </div>
          </div>
        )}
        
        <div className="absolute top-8 left-8 z-[210] flex gap-4">
            <div className="px-4 py-2 glass rounded-full flex items-center gap-3 border border-white/10">
                <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse" />
                <span className="text-[10px] font-black uppercase tracking-[0.4em] text-white/60">Neural Playtest Active</span>
            </div>
            <button 
                onClick={() => setIsPreviewing(false)}
                className="px-6 py-2 glass rounded-full hover:bg-white hover:text-black transition-all font-black text-[10px] uppercase tracking-[0.3em]"
            >
                EXIT PREVIEW
            </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-neutral-900 text-white p-6 font-inter overflow-hidden relative animate-in fade-in duration-500">
      <div className="w-72 flex flex-col gap-4 bg-neutral-800 p-4 rounded-xl overflow-y-auto z-10 shadow-2xl">
        <h1 className="text-xl font-orbitron mb-4 text-center tracking-widest text-white/90">EDITOR</h1>
        
        <div className="mb-4">
          <label className="text-[10px] uppercase font-black text-zinc-500 tracking-widest block mb-2">Level Details</label>
          <input 
            type="text" 
            value={level.name} 
            onChange={(e) => setLevel({...level, name: e.target.value})}
            className="w-full bg-neutral-700 border border-neutral-600 rounded p-2 text-sm focus:outline-none focus:border-white transition-colors"
            placeholder="Level Name"
          />
        </div>

        <button 
          onClick={startPreview}
          className="w-full py-5 bg-white text-black font-black text-xs rounded-xl flex items-center justify-center gap-3 border border-white/10 hover:scale-[1.02] active:scale-95 transition-all shadow-[0_0_20px_rgba(255,255,255,0.1)] group"
        >
          <span className="text-lg group-hover:scale-110 transition-transform">▶</span> NEURAL PLAYTEST
        </button>

        <button 
          onClick={() => setConfirmingAction('ARCHIVE')}
          className="w-full py-4 glass text-white/60 font-black text-xs rounded-xl flex items-center justify-center gap-3 border border-white/5 hover:bg-white/5 hover:text-white transition-all active:scale-95 group"
        >
          <span className="text-lg group-hover:animate-pulse">🧠</span> AI ARCHIVE
        </button>

        <div className="mb-6 space-y-2 mt-2">
          <label className="text-[10px] uppercase font-black text-zinc-500 tracking-widest block mb-2">Editor Settings</label>
          <button 
            onClick={() => setSnapToGrid(!snapToGrid)}
            className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all ${snapToGrid ? 'bg-white/5 border-white/20' : 'bg-neutral-700 border-transparent text-zinc-500'}`}
          >
            <span className="text-[10px] font-black uppercase tracking-widest">Snap to Grid</span>
            <div className={`w-10 h-5 rounded-full relative transition-colors ${snapToGrid ? '' : 'bg-zinc-600'}`} style={{ backgroundColor: snapToGrid ? settings.primaryColor : undefined }}>
              <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${snapToGrid ? 'left-6' : 'left-1'}`} />
            </div>
          </button>
        </div>

        <div className="mb-6 space-y-2">
          <label className="text-[10px] uppercase font-black text-zinc-500 tracking-widest block mb-2">History</label>
          <div className="grid grid-cols-2 gap-2">
            <button 
              disabled={undoStack.length === 0}
              onClick={undo}
              className="flex items-center justify-center gap-2 p-2 bg-neutral-700 rounded text-[10px] font-bold uppercase transition disabled:opacity-20 hover:bg-neutral-600 active:scale-95"
            >
              <span className="text-sm">↩</span> Undo
            </button>
            <button 
              disabled={redoStack.length === 0}
              onClick={redo}
              className="flex items-center justify-center gap-2 p-2 bg-neutral-700 rounded text-[10px] font-bold uppercase transition disabled:opacity-20 hover:bg-neutral-600 active:scale-95"
            >
              <span className="text-sm">↪</span> Redo
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <label className="text-[10px] uppercase font-black text-zinc-500 tracking-widest block mb-2 col-span-2">Toolbox</label>
          {Object.values(ObjectType).map(type => (
            <button 
              key={type}
              onClick={() => setActiveTool(type)}
              className={`p-2 text-[9px] uppercase font-bold rounded border transition ${activeTool === type ? 'bg-white text-black border-white' : 'bg-neutral-700 border-transparent text-zinc-400 hover:text-white'}`}
            >
              {type.replace('PORTAL_', '')}
            </button>
          ))}
          <button 
            onClick={() => setActiveTool('ERASER')}
            className={`p-2 text-xs font-bold rounded border col-span-2 transition ${activeTool === 'ERASER' ? 'bg-red-600 border-red-400 text-white' : 'bg-neutral-700 border-transparent text-zinc-400 hover:text-white'}`}
          >
            ERASER
          </button>
        </div>
        
        <div className="mt-auto space-y-2 pt-4 border-t border-neutral-700">
            <button onClick={() => setConfirmingAction('CLEAR')} className="w-full py-2 bg-neutral-700 border border-red-500/30 text-red-400 text-xs rounded font-bold hover:bg-red-500/10 transition active:scale-95 uppercase tracking-widest">CLEAR ALL</button>
            <button onClick={() => setConfirmingAction('SAVE')} className="w-full py-3 bg-emerald-600 rounded font-bold hover:bg-emerald-500 transition shadow-lg shadow-emerald-900/20 active:scale-95 uppercase tracking-widest">SAVE LEVEL</button>
            <button onClick={() => setConfirmingAction('EXIT')} className="w-full py-2 bg-zinc-700 rounded font-bold hover:bg-zinc-600 transition active:scale-95 uppercase tracking-widest">EXIT</button>
        </div>
      </div>

      <div className="flex-1 flex flex-col gap-4 px-6 overflow-hidden z-10">
        <div className="bg-black rounded-xl border-2 border-neutral-700 relative overflow-hidden flex-1 shadow-inner group">
          <canvas 
            ref={canvasRef} width={GAME_WIDTH} height={GAME_HEIGHT} 
            onMouseDown={handleCanvasClick} 
            className="cursor-crosshair w-full h-full object-contain"
          />
          <div className="absolute top-4 right-4 bg-white/5 border border-white/10 px-3 py-1 rounded-full pointer-events-none opacity-50 group-hover:opacity-100 transition-opacity">
            <span className="text-[9px] text-white/30 uppercase font-black tracking-widest">
              {snapToGrid ? 'Grid Snapping Active' : 'Pixel-Perfect Active'}
            </span>
          </div>
          <div className="absolute bottom-4 right-4 bg-white/5 px-2 py-0.5 rounded text-[8px] text-white/20 uppercase font-black tracking-tighter">
            Spatial Indexing: Active ({level.objects.length} entities)
          </div>
        </div>
        <div className="flex items-center gap-6 bg-neutral-800/50 p-4 rounded-xl border border-white/5">
            <div className="flex flex-col min-w-[100px]">
                <span className="text-[10px] text-zinc-500 uppercase font-black tracking-widest">Temporal Position</span>
                <span className="text-lg font-mono text-white/80">{Math.round(scrollX)}px</span>
            </div>
            <input 
              type="range" min="0" max="20000" value={scrollX} 
              onChange={(e) => setScrollX(parseInt(e.target.value))}
              className="flex-1 h-2 bg-zinc-700 rounded-lg appearance-none cursor-pointer"
              style={{ accentColor: settings.primaryColor }}
            />
        </div>
      </div>

      {confirmingAction === 'ARCHIVE' && (
        <div className="absolute inset-0 z-[110] bg-black/95 backdrop-blur-3xl flex items-center justify-center p-8 animate-in fade-in duration-500">
           <div className="max-w-4xl w-full h-full max-h-[80vh] flex flex-col glass rounded-[56px] p-12 animate-in zoom-in duration-300">
              <div className="flex justify-between items-start mb-10">
                <div>
                  <h2 className="text-5xl font-orbitron font-black tracking-tighter uppercase">Neural Archive</h2>
                  <p className="text-zinc-500 text-[10px] uppercase font-black tracking-[0.4em] mt-2">Manifestation History Log</p>
                </div>
                <button 
                  onClick={() => setConfirmingAction(null)}
                  className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors"
                >
                  <span className="text-xl">✕</span>
                </button>
              </div>

              {aiHistory.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center">
                  <span className="text-6xl mb-6 opacity-20">🌫️</span>
                  <p className="text-zinc-500 font-black text-xs uppercase tracking-widest">Archive is empty. Generate levels via Puppet AI to populate logs.</p>
                </div>
              ) : (
                <div className="flex-1 overflow-y-auto pr-4 space-y-4">
                  {aiHistory.map((item) => (
                    <div 
                      key={item.id}
                      className="group p-8 glass rounded-[40px] border border-white/5 hover:border-white/20 transition-all flex flex-col md:flex-row md:items-center justify-between gap-6"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-4 mb-2">
                           <h3 className="text-xl font-orbitron font-black">{item.name}</h3>
                           <span className="px-2 py-0.5 rounded-full bg-white/5 text-[8px] font-black text-zinc-500 uppercase tracking-widest">
                             {new Date(item.timestamp).toLocaleDateString()}
                           </span>
                        </div>
                        <p className="text-zinc-400 text-xs italic line-clamp-2 max-w-xl">"{item.prompt}"</p>
                        <div className="mt-4 flex gap-4">
                           <span className="text-[10px] font-black uppercase text-zinc-600 tracking-widest">
                             Entities: {item.objects.length}
                           </span>
                           <span className="text-[10px] font-black uppercase text-zinc-600 tracking-widest">
                             Length: {Math.max(...item.objects.map(o => o.x), 0).toFixed(0)}px
                           </span>
                        </div>
                      </div>
                      <div className="flex gap-4">
                         <button 
                          onClick={() => applyArchiveLayout(item.objects)}
                          className="px-10 py-4 bg-white text-black font-black text-sm rounded-full hover:scale-105 active:scale-95 transition-all shadow-xl"
                         >
                           APPLY LAYOUT
                         </button>
                         <button 
                          onClick={() => {
                            const newHistory = aiHistory.filter(h => h.id !== item.id);
                            setAiHistory(newHistory);
                            localStorage.setItem('puppet_dash_ai_history', JSON.stringify(newHistory));
                          }}
                          className="w-14 h-14 rounded-full border border-red-500/20 text-red-500/40 hover:text-red-500 hover:bg-red-500/5 flex items-center justify-center transition-all"
                         >
                           <span className="text-lg">🗑️</span>
                         </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-10 pt-8 border-t border-white/5 flex justify-center">
                <button 
                  onClick={() => setConfirmingAction(null)}
                  className="text-zinc-600 font-black text-[10px] uppercase tracking-[0.6em] hover:text-white transition-colors"
                >
                  Return to Workshop
                </button>
              </div>
           </div>
        </div>
      )}

      {confirmingAction && confirmingAction !== 'ARCHIVE' && (
        <div className="absolute inset-0 z-[120] bg-black/80 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="max-w-md w-full glass p-10 rounded-[48px] border border-white/10 text-center animate-in zoom-in duration-300 shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-6 border border-white/10">
              <span className="text-2xl">
                {confirmingAction === 'SAVE' ? '💾' : confirmingAction === 'EXIT' ? '🚪' : '🗑️'}
              </span>
            </div>
            <h2 className="text-3xl font-orbitron font-black mb-4 tracking-tighter uppercase">
              {confirmingAction === 'SAVE' ? 'Commit Changes?' : confirmingAction === 'EXIT' ? 'Terminate Session?' : 'Purge Layout?'}
            </h2>
            <p className="text-zinc-400 text-sm font-medium mb-10 leading-relaxed px-4">
              {confirmingAction === 'SAVE' 
                ? 'This will finalize the neural layout into the level registry and purge the temporary session buffer.' 
                : confirmingAction === 'EXIT' 
                ? 'Any unsaved progress in this workshop session will be permanently erased.'
                : 'This will delete all objects from the current layout. This action can be undone.'}
            </p>
            <div className="flex flex-col gap-4">
              <button 
                onClick={handleConfirmAction}
                className={`py-5 rounded-3xl font-black text-lg transition-all active:scale-95 shadow-lg ${confirmingAction === 'SAVE' ? 'bg-emerald-600 text-white shadow-emerald-900/20' : confirmingAction === 'CLEAR' ? 'bg-red-500 text-white shadow-red-900/20' : 'bg-red-600 text-white shadow-red-900/20'}`}
              >
                {confirmingAction === 'SAVE' ? 'FINALIZE SEQUENCE' : confirmingAction === 'EXIT' ? 'EXIT WORKSHOP' : 'PURGE EVERYTHING'}
              </button>
              <button 
                onClick={() => setConfirmingAction(null)}
                className="py-4 text-zinc-500 hover:text-white font-bold text-[10px] uppercase tracking-[0.3em] transition-colors"
              >
                RETURN TO EDITOR
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Editor;
